import React from "react";
import FlightInput from "../components/FlightInput";
import { useState , useContext} from "react";
import FlightsList from "../components/FlightsList";
import FlightSearch from "../components/FlightSearch";
import { authContext } from "../../auth-context/auth-context";
const Flights = (props) => {
  const [flightsData, setflightsData] = useState([]);
  const [ status, setstatus ] = useState();
  const onloadFlightDataHandler = (data,okStatus) => {
    setflightsData(data);
    setstatus(okStatus);
  };
  const ctx = useContext(authContext);
  return (
    <React.Fragment>
     <FlightInput loadFlightData={onloadFlightDataHandler}></FlightInput>  
     { ctx.searchButton &&   <FlightsList  status={status} flights={flightsData}> </FlightsList>  } 
   {/* <div className="container shadow-lg bg-body rounded">   
    {  flightsData.map((item)=> <FlightSearch airlines={item.airlineName}  >   </FlightSearch>  )         }
    </div> */}
    </React.Fragment>
  );
};

export default Flights;
