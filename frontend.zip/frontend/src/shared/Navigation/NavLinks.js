import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { authContext } from '../../auth-context/auth-context';
import './NavLinks.css';
import { useContext } from 'react'
const NavLinks = props => {
  
  const ctx =  useContext(authContext);
  
  

  
  // if( undefined ||  !ctx.userDetails.role){
  //   role="user";
  //   console.log(role);
  // }
  const onClickHandler = ()=>{
    ctx.logout();
  }

  return <ul className="nav-links">
    
    <li> 
      { ctx.isLogged &&  <Link to='/allorders'> My Ticket Orders History </Link> }
       </li>
    <li> 
     { !ctx.isLogged &&   <NavLink to="/login"> User Login </NavLink>  } 
    </li>
  <li>
     {  ctx.isLogged &&  <NavLink to="/orders"> My Current Booking Order </NavLink> }  
    </li>
    <li>  
     { ctx.isLogged  && <Link to='/' onClick={onClickHandler} >  LogOut  </Link>  } 
    </li>
    <li>  
     { !ctx.isLogged  && <Link to='/admin' onClick={onClickHandler} >  Admin Login  </Link>  } 
    </li>
    <li>  
 { ctx.role !== 0 && ctx.isLogged ?  <Link to='/flights' > Flight Management Page </Link> : ""  }   
    </li>
  </ul>
};

export default NavLinks;