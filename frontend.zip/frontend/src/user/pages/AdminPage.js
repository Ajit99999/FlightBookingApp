import React  from "react";

import Admin from "../components/Admin";
const AdminPage = ()=>{
return <Admin></Admin>
}
export default AdminPage