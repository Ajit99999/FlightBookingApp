import React from "react";
import OrderList from "../components/OrderList";

const OrderPage = (props) => {
  return <OrderList></OrderList>;
};

export default OrderPage;
