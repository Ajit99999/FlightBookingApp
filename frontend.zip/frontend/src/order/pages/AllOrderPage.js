import React from "react";
import AllOrderList from "../components/AllOrderList";

const AllOrderPage = () =>{
  return <AllOrderList></AllOrderList>
}
export default AllOrderPage;