import React from "react";
import OrderItem from "./OrderItem";
import { useEffect, useContext, useState } from "react";
import { authContext } from "../../auth-context/auth-context";


const OrderList = (props) => {

  let storedOrderId = localStorage.getItem("orderId");
  const [userState, setuserState] = useState(null);
  const [flightState, setflightState] = useState(null);
  const [orderId, setorderId] = useState(null);
  
  const [errorState, seterrorState] = useState(null);
  const [weatherState, setweatherState] = useState(null);
  const [ imageState, setimageState ] = useState(null);

  let storedToken = localStorage.getItem("token");
  useEffect(() => {
    
   
    let data;
    let url = `http://localhost:8000/api/order/searchorder/${storedOrderId}`;
    const fetchOrder = async () => {
      try {
    
        let response = await fetch(url, {
          method: "GET",
          headers: {
            Authorization: storedToken,
          },
        });
        if (!response.ok) {
          console.log("error");
        }

        data = await response.json();
       
        setuserState(data.existingOrder.creator);
        setflightState(data.flightDetails.flight);
        setorderId(data.existingOrder.id);
        seterrorState(null);
      } catch (err) {
        seterrorState(err.message);
      }
      // calling the Weather using Extrenal Open Weather Api
      try {
        let weatherRes = await fetch(
          `https://api.openweathermap.org/data/2.5/weather?q=${data.flightDetails.flight.toPlace}&appid=your_appIdname`
        );

        if (!weatherRes.ok) {
          throw new Error("some thing went wrong");
        }
        let weatherData = await weatherRes.json();

        let temp = weatherData.main.temp - 270;
        temp = temp.toString().slice(0, 4);
        let condition = weatherData.weather[0].description;
        let weather = temp +  "Celcius" + " " + condition;

        setweatherState(weather);
        setimageState(weatherData.weather[0].icon)
      } catch (err) {
        console.log(err.message);
      }
    };

    fetchOrder();
  }, [storedOrderId , storedToken]);

  const overallOrderHandler = () => {
    setuserState(null);
    setflightState(null);
    setorderId(null);
  };

  if (!userState || !flightState) {
    return (
      <div className="container col-4 mt-4  shadow-lg  p-5 bg-body rounded">
        <div className="row">
          <div className="col-3"></div>
          <div className="col">No Orders Present</div>
        </div>
      </div>
    );
  }

  return (
    <React.Fragment>
    
      <OrderItem
        overallOrder={overallOrderHandler}
        orderId={orderId}
        name={userState.name}
        email={userState.email}
        address={userState.address}
        fromPlace={flightState.fromPlace}
        toPlace={flightState.toPlace}
        airlineName={flightState.airlineName}
        flightDate={flightState.flightDate}
        flightid={flightState._id}
        weather={weatherState}
        price={flightState.price}
        image={imageState}
      ></OrderItem>
    </React.Fragment>
  );
};
export default OrderList;
