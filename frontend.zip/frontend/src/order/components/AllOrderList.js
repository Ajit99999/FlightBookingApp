import React from "react";
import AllOrderItem from "./AllOrderItem";
import { authContext } from "../../auth-context/auth-context";
import { useEffect, useState, useContext } from "react";

import { BiRupee } from "react-icons/bi";
const AllOrderList = () => {
  const ctx = useContext(authContext);
  
  let storedToken = localStorage.getItem("token");
  let userId = localStorage.getItem("userId");

  let url = `http://localhost:8000/api/user/orders/${userId}`;

  const [orderState, setorderState] = useState([]);
  const [ priceState, setpriceState  ] = useState(null);
  useEffect(() => {
    const fetchAllOrders = async () => {
      try {
        let response = await fetch(url, {
          method: "GET",
          headers: {
            Authorization: storedToken,
          },
        });

        if (!response.ok) {
          console.log("error");
        }

        let data = await response.json();

        setorderState(data.orders);
        
        
        setpriceState(data.user[0].creator.totalPrice);

      } catch (err) {
        console.log(err);
      }
    };
    fetchAllOrders();
  }, []);

 let  userDetailsPage =  <div className="container col-6   shadow-lg   bg-body rounded">
 <div className="row pt-2 pb-2 border-bottom bg-info">  
      <div className="d-flex justify-content-center text-dark "> User Details </div>
      </div>
  <div className="row ps-4">
  <div className="col-3 ps-4 bg-light"> User Name: </div>
        <div className="col-3 ps-4 bg-light "> User Address </div>
        <div className="col-3 ps-4 bg-light "> User Email: </div>
        </div>
        <div className="row ps-4">
    <div className="col-3 ps-4">  {ctx.userDetails.name} </div>
    <div className="col-3 ps-4"> {ctx.userDetails.address}</div>
    <div className="col ps-4 "> {ctx.userDetails.email}</div>
    
  </div>
  <div className="row pt-2 ps-n2">
   
    <div className="col bg-light d-flex justify-content-center">Total Orders Price: </div>
  </div>
  <div className="row pt-2 ">
   
    <div className="col  d-flex justify-content-center">  
     <BiRupee style={{marginTop:"5.5px"}} />  {priceState}</div>
  </div>
</div>
  if (!orderState) {
    return (
      <div className="container col-4 mt-4  shadow-lg  p-5 bg-body rounded">
        <div className="row">
          <div className="col-3"></div>
          <div className="col">No Orders Present</div>
        </div>
      </div>
    );
  }
  return (
    <React.Fragment>
   { userDetailsPage } 
     
      {orderState.map((item) => (

        <AllOrderItem
          key={item._id}
          orderId={item._id}
          fromPlace={item.flight.fromPlace}
          toPlace={item.flight.toPlace}
          airlineName={item.flight.airlineName}
          flightDate={item.flight.flightDate}
          price={item.flight.price}
          flightId={item.flight._id}
        ></AllOrderItem>
      ))}
      
    </React.Fragment>
  );
};

export default AllOrderList;
