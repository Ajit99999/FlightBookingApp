import React from "react";
import { useHistory } from "react-router-dom";

const FlightItemManage = (props) => {
  let storedToken = localStorage.getItem("token");

  const history = useHistory();

  const onDeleteHandler = async (event) => {
    try {
      await fetch(`http://localhost:8000/api/flight/deleteflight/${props.id}`, {
        method: "DELETE",
        headers: {
          Authorization: storedToken,
        },
      });
      history.push("/");
    } catch (err) {
      console.log(err.message);
    }
  };

  return (
    <React.Fragment>
      <tbody>
        <tr>
          <td>{props.fromPlace}</td>
          <td>{props.toPlace}</td>
          <td>{props.flightDate}</td>
          <td>{props.airlineName}</td>
          <td>
            {props.totalTickets}
      
          </td>
          <td>{props.price}</td>
          <td>
            <button
             
              type="button"
              onClick={onDeleteHandler}
              className="btn-danger"
            >
             
              Delete
            </button>
          </td>
        </tr>
      </tbody>
    </React.Fragment>
  );
};

{
  /* <tbody>
<tr>
  <td>
    <input
      class="form-control"
      type="text"
      placeholder="Enter Arrival Place"
      disabled={true}
      value={props.fromPlace}
    />
  </td>
  <td>
    <input
      class="form-control"
      type="text"
      value={props.toPlace}
      disabled={true}
    />
  </td>
  <td>
    <input
      class="form-control"
      type="Date"
      value={props.flightDate}
      disabled={true}
    />
  </td>
  <td>
    <input
      class="form-control"
      type="text"
      value={props.airlineName}
      disabled={true}
    />
  </td>
  <td>
    <input
      class="form-control"
      type="number"
      value={props.totalTickets}
      disabled={true}
    />
  </td>
  <td>
    {" "}
    <input
      class="form-control"
      type="number"
      value={props.price}
      disabled={true}
    />
  </td>
   <td>
    <button
      style={{marginTop:"20px"}}
      type="button"
      onClick={onDeleteHandler}
      className="btn-danger"
    >
      {" "}
      Delete{" "}
    </button>{" "}
  </td>
</tr>
</tbody> */
}
export default FlightItemManage;
