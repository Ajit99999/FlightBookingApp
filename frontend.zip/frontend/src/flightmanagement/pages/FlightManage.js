import React from "react";
import FlightListsManage from "../components/FlightListsManage";
import FlightManageForm from "../components/FlightManageForm";

const FlightManage = ()=>{
    

    
    return <React.Fragment>
 <FlightManageForm   />
<FlightListsManage   ></FlightListsManage>
    </React.Fragment>
    
    
    
}

export default FlightManage;

