import React from "react";
import { BrowserRouter, Route, Switch, Redirect } from "react-router-dom";
import OrderPage from "./order/pages/OrderPage";
import Flights from "./flight/pages/Flights";
import Admin from "./user/components/Admin";
import Auth from "./user/components/Auth";
import MainNavigation from "./shared/Navigation/MainNavigation";
import AuthContextComponent from "./auth-context/auth-context";
import AllOrderPage from "./order/pages/AllOrderPage";
import FlightManage from "./flightmanagement/pages/FlightManage";

function App() {
  return (
    <AuthContextComponent>
      <BrowserRouter>
        <MainNavigation />
        <main>
          <Switch>
            <Route path="/" exact>
              <Flights></Flights>
            </Route>
            <Route path="/login" exact>
              <Auth></Auth>
            </Route>
            <Route path="/admin" exact>
              <Admin></Admin>
            </Route>
            <Route path="/orders" exact>
              <OrderPage> </OrderPage>
            </Route>
            <Route path="/allorders" exact>
              <AllOrderPage></AllOrderPage>
            </Route>

             <Route path="/flights"  > 
                 <FlightManage></FlightManage>
                 </Route>
            <Route path="*">
              <Redirect to="/"></Redirect>
            </Route>
          </Switch>
        </main>
      </BrowserRouter>
    </AuthContextComponent>
  );
}

export default App;
