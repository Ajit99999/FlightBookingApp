import React, { useState } from "react";
import { authContext } from "../../auth-context/auth-context";
import { useContext } from "react";
import { useHistory } from "react-router";
import { MdFlight } from "react-icons/md";
import { BsCalendar3 } from "react-icons/bs";
import { MdLocationCity } from "react-icons/md";
import { BiRupee } from "react-icons/bi";
import { GrSelect } from 'react-icons/gr'
const FlightItem = (props) => {
  const history = useHistory();
  const [errorState, seterrorState] = useState(null);
  const ctx = useContext(authContext);
  const flightId = props.id;

  let storedToken = localStorage.getItem("token");
  let userId = localStorage.getItem("userId");

  const onSumbitHandler = async (event) => {
    event.preventDefault();
    if (!ctx.isLogged) {
      seterrorState("You have not been logged in");
      history.replace("/login");
      return;
    }

    try {
      let response = await fetch(
        "http://localhost:8000/api/order/createorder",
        {
          method: "POST",
          headers: {
            Authorization: storedToken,
            "Content-Type": "application/json",
          },

          body: JSON.stringify({
            flightId: flightId,
            creator: userId,
          }),
        }
      );

      let data = await response.json();
      if (!response.ok) {
        throw new Error(data.message);
      }
      ctx.setorderId(data.order.id);
      localStorage.setItem("orderId", data.order.id);
      history.push("/orders");
    } catch (err) {
      seterrorState(err.message);
    }
  };

  console.log(errorState);

  return (
    <React.Fragment>
      <div className="container shadow-lg bg-body rounded mt-2"  style={{height:"70px"}}>
        <div className="row" style={{paddingTop:"15px"}}>
          <div className="col">
            <MdFlight style={{ height: "25px", width: "25px" }}></MdFlight>{" "}
            {props.airlineName}
          </div>

          <div className="col">
            <MdLocationCity style={{ height: "22px", width: "22px" }} />
            {props.fromPlace}
          </div>
          <div className="col">
            <MdLocationCity style={{ height: "22px", width: "22px" }} />{" "}
            {props.toPlace}
          </div>
          <div className="col">
            <BsCalendar3 style={{ height: "20px", width: "20px" }} />{" "}
            {props.flightDate.slice(0, 10)}
          </div>
          <div className="col">
          <BiRupee style={{ height: "22px", width: "22px" }} /> {props.price} 
          </div>
          <div className="col">
            <button 
              type="submit"
              onClick={onSumbitHandler}
              className="rounded-pill  border border-2 px-4"
            >
                <GrSelect  style={{ height: "20px", width: "20px" }}/>
              Book
            </button>
          </div>
        </div>

      </div>
    </React.Fragment>
  );
};

export default FlightItem;
