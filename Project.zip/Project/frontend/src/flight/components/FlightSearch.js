import React from "react";

const FlightSearch = (props)=>{
return (    <React.Fragment>  
        <div style={{position:"relative" , left:"100px" , top:"-400px" }} className="container row">
          <div className="col">
            <p className="d1"> {props.airlines}  </p> <input type="radio"></input>
          </div>
          </div>
</React.Fragment> )
}

export default FlightSearch;