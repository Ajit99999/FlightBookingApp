import React from "react";
import FlightItem from "./FlightItem";

const FlightsList = (props) => {
  if (!props.flights || props.flights.length === 0) {
    return (
      <div className="container col-md-4  shadow-lg p-5 mb-5 bg-body rounded">
        <div className="row">
          <div className="col-md-3"></div>
          <div className="col">No Flights Present</div>
        </div>
      </div>
    );
  }

  return (
    <section className="products">
      <ul>
        {props.flights.map((item) => (
          <FlightItem
            key={item._id}
            id={item._id}
            fromPlace={item.fromPlace}
            toPlace={item.toPlace}
            flightDate={item.flightDate}
            totalTickets={item.totalTickets}
            airlineName={item.airlineName}
            price={item.price}
          ></FlightItem>
        ))}
      </ul>
    </section>
  );
};
export default FlightsList;
