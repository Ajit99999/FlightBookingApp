import React from "react";
import { useRef, useContext, useState } from "react";
import { authContext } from "../../auth-context/auth-context";
let City = [
  {
    id: "c1",
    fromPlace: "Mumbai",
    toPlace: "Delhi",
  },
  {
    id: "c2",
    fromPlace: "Delhi",
    toPlace: "HyderaBad",
  },
  {
    id: "c3",
    fromPlace: "Bhubaneswar",
    toPlace: "Bangalore",
  },
  {
    id: "c4",
    fromPlace: "HyderaBad",
    toPlace: "Mumbai",
  },
];

const FlightInput = (props) => {
  const [errorState, seterrorState] = useState(null);
  const [errorState1, seterrorState1] = useState(null);
  const [errorState2, seterrorState2] = useState(null);
  const ctx = useContext(authContext);
  const fromPlaceRef = useRef();
  const toPlaceRef = useRef();
  const fromDateRef = useRef();
  const toDateRef = useRef();

  const onSubmitHandler = async (event) => {
    event.preventDefault();
    const fromPlaceValue = fromPlaceRef.current.value;
    const toPlaceValue = toPlaceRef.current.value;
    const fromDateValue = fromDateRef.current.value;
    const toDateValue = toDateRef.current.value;

    if (!fromPlaceValue || !toPlaceValue || !fromDateValue) {
      console.log("Please Enter All the Value");
      seterrorState(true);
      return;
    }

    if (fromPlaceValue.toLowerCase() === toPlaceValue.toLowerCase()) {
      console.log("Place Can not be Equal");
      seterrorState(null);
      seterrorState1(true);
      return;
    }

    if (new Date(fromDateValue) > new Date(toDateValue)) {
      console.log("From Date Can not be Greater Than Equal");
      seterrorState(null);
      seterrorState1(null);
      seterrorState2(true);
      return;
    }

    
    try {
      const res = await fetch("http://localhost:8000/api/user/searchflight", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fromPlace: fromPlaceValue,
          toPlace: toPlaceValue,
          fromDate: fromDateValue,
        }),
      });

      let okStatus = res.ok;
      const data = await res.json();
      ctx.searchButtonClick();
      seterrorState1(null);
      seterrorState2(null);
      seterrorState(null);
       
       props.loadFlightData(data.flight, okStatus);

     
    } catch (err) {
      console.log(err.message);
      
    }
  };
  return (
    <form className="row" onSubmit={onSubmitHandler}>
      <div className="col-md-2"> </div>
      <div style={{ marginTop: "13px" }} className="col-md-2">
        <label htmlFor="validationCustom04" className="form-label">
          From Place
        </label>
        <select
          ref={fromPlaceRef}
          className="form-select"
          id="validationCustom04"
        >
          <option>Choose City...</option>
          {City.map((city) => (
            <option key={city.id} value={city.fromPlace}>
              {city.fromPlace}
            </option>
          ))}
        </select>
        <div className="invalid-feedback">Please select a From Place.</div>
      </div>
      <div style={{ marginTop: "13px" }} className="col-md-2">
        <label htmlFor="validationCustom04" className="form-label">
          To Place
        </label>
        <select
          ref={toPlaceRef}
          className="form-select"
          id="validationCustom04"
        >
          <option>Choose City...</option>
          {City.map((city) => (
            <option key={city.id} value={city.toPlace}>
              {city.toPlace}
            </option>
          ))}
        </select>
        <div className="invalid-feedback">Please select a To Place.</div>
      </div>

      <div style={{ marginTop: "13px" }} className="col-md-2">
        <label htmlFor="validationCustom03" className="form-label">
          From Date
        </label>
        <input
          style={{ marginTop: "1.5px" }}
          ref={fromDateRef}
          type="Date"
          className="form-control"
          id="validationCustom03"
        />
        <div className="invalid-feedback">Please provide a valid city.</div>
      </div>

      <div style={{ marginTop: "13px" }} className="col-md-2">
        <label htmlFor="validationCustom03" className="form-label">
          To Date
        </label>
        <input
          style={{ marginTop: "1.5px" }}
          ref={toDateRef}
          type="Date"
          className="form-control"
          id="validationCustom03"
        />
        <div className="invalid-feedback">Please provide a valid city.</div>
      </div>
      <div
        style={{ paddingLeft: "170px" }}
        className="row mt-2 ms-4 d-flex justify-content-center"
      >
        <div className="col-4 ">
          {errorState && (
            <p style={{ color: "red", fontSize: "15px" }}>
              {" "}
              Please Enter All the Value{" "}
            </p>
          )}
        </div>
        <div className="row mt-2 d-flex justify-content-center">
          <div className="col-4 ">
            {errorState1 && (
              <p style={{ color: "red", fontSize: "15px" }}>
                
               Arrival & Destination Places Can Not Be Equal
              </p>
            )}
          </div>
        </div>
        <div className="row mt-2 d-flex justify-content-center">
          <div className="col-4 ">
            {errorState2 && (
              <p style={{ color: "red", fontSize: "15px" }}>
                
               From Date Can Not Be Greater Than To Date
              </p>
            )}
          </div>
        </div>
      </div>
      <div className="row mt-4">
        <div className="col-md-1"> </div>
        <div className="col-md-3"> </div>
        <div className="col-md-2"> </div>
        <div className="col-md-2 ps-n2">
          <button className="btn btn-primary" type="submit">
            Search
          </button>
        </div>
      </div>
      <div className="row">
        <div className="col p-4"> </div>
        <div className="col"> </div>
        <div className="col"> </div>
      </div>
    </form>
  );
};

export default FlightInput;
