import React from "react";
import FlightItemManage from "./FlightItemManage";

import { useState, useEffect  } from "react";
import { useHistory } from 'react-router-dom'
import LoadingSpinner from "../../shared/UIelements/LoadingSpinner";
const FlightListsManage = () => {
  const history = useHistory();
  const [ flightData , setflightData  ] = useState([]);
  const [ loadingState, setloadingState   ] = useState(false);
  let storedToken = localStorage.getItem("token");
 
  
  useEffect(() => {
    const fetchFlight = async () => {
      try {
        setloadingState(true);
        let response = await fetch(
          "http://localhost:8000/api/flight/getflights",
          {
            headers: {
              Authorization: storedToken,
            },
          }
        );
        let data = await response.json();
        setloadingState(false);
        setflightData(data.flights);
      } catch (err) {
        console.log(err.message);
      }
    };
    
    fetchFlight();
  },[]);
  
  if ( !flightData || flightData.length === 0) {
    return (
      <div className="container shadow-sm  bg-body rounded px-4">
        <div className="row">
          <div className="col px-4">No data Present</div>
        </div>
      </div>
    );
  }
  return (
    <React.Fragment>
      {loadingState && <LoadingSpinner asOverlay />  } 
      <table className="table-bordered table table-info mt-4 ">
        <thead>
          <tr>
            <th scope="col"> Arrival </th>
            <th scope="col">Departure</th>
            <th scope="col">Flight Date</th>
            <th scope="col">Airline Name</th>
            <th scope="col"> Total Tickets </th>
            <th scope="col"> Ticket Price </th>
            <th  >
              Actions
            </th>
          </tr>
        </thead>
        {flightData.map((item) => (
          <FlightItemManage
          
            key={item._id}
            id={item._id}
            fromPlace={item.fromPlace}
            toPlace={item.toPlace}
            flightDate={item.flightDate.slice(0,10)}
            totalTickets={item.totalTickets}
            airlineName={item.airlineName}
            price={item.price}
          />
        ))}
      </table>
    </React.Fragment>
  );
};

export default FlightListsManage;
