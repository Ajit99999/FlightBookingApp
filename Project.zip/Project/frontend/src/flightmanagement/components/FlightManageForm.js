import React from "react";
import { useRef } from "react";
import { useHistory } from "react-router";
const FlightManageForm = () => {
  let history = useHistory();
  const fromPlaceRef = useRef();
  const toPlaceRef = useRef();
  const flightDateRef = useRef();
  const totalTicketsRef = useRef();
  const priceRef = useRef();
  const airlineNameref = useRef();
  let storedToken = localStorage.getItem("token");

  const onSubmitHandler = async (event) => {
    event.preventDefault();
    const fromPlaceRefInput = fromPlaceRef.current.value;

    const toPlaceRefInput = toPlaceRef.current.value;
    const flightDateRefInput = flightDateRef.current.value;
    const totalTicketsRefInput = totalTicketsRef.current.value;
    const priceRefInput = priceRef.current.value;
    const airlineNamerefInput = airlineNameref.current.value;
    if (
      !toPlaceRefInput ||
      !flightDateRefInput ||
      !totalTicketsRefInput ||
      !priceRefInput ||
      !airlineNamerefInput ||
      !fromPlaceRefInput
    ) {
      console.log("Please give all the Input Value");
      return;
    }
    if (fromPlaceRefInput.toLowerCase() === toPlaceRefInput.toLowerCase()) {
      console.log("Arrival & Destination Places can not be Equal");
      return;
    }
    if (totalTicketsRefInput <= 0 || priceRefInput <= 0) {
      console.log("Total Tickets & Price Can not be less than Zero");
      return;
    }

    let flightInfoObj = {
      fromPlace: fromPlaceRefInput,
      toPlace: toPlaceRefInput,
      flightDate: flightDateRefInput,
      price: priceRefInput,
      airlineName: airlineNamerefInput,
      totalTickets: totalTicketsRefInput,
    };

    console.log(flightInfoObj);
    try {
      await fetch("http://localhost:8000/api/flight/createflight", {
        method: "POST",
        headers: {
          Authorization: storedToken,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fromPlace: flightInfoObj.fromPlace,
          toPlace: flightInfoObj.toPlace,
          flightDate: flightInfoObj.flightDate,
          totalTickets: flightInfoObj.totalTickets,
          airlineName: flightInfoObj.airlineName,
          price: flightInfoObj.price,
        }),
      });
      history.push('/')
    } catch (err) {
      console.log(err.message);
    }
  };
  return (
    <React.Fragment>
      <form
        onSubmit={onSubmitHandler}
        className="container shadow-sm  bg-body rounded px-4"
      >
        <div className="row">
          <div className="col px-4">Arrival</div>
          <div className="col px-4">Departure</div>
          <div className="col px-4">Flight Date</div>
          <div className="col px-4">Airline Name</div>
          <div className="col px-7">Total Tickets</div>
          <div className="col px-7">Ticket Price</div>
        </div>

        <div className="row">
          <div className="col">
            <input
              className="form-control"
              type="text"
              placeholder="Enter Arrival Place"
              aria-label=".form-control-sm example"
              ref={fromPlaceRef}
            />
          </div>
          <div className="col">
            <input
              class="form-control"
              type="text"
              placeholder="Enter Destination Place"
              aria-label=".form-control-sm example"
              ref={toPlaceRef}
            />
          </div>
          <div className="col">
            <input
              class="form-control"
              type="date"
              placeholder="Enter Flight Date"
              aria-label=".form-control-sm example"
              ref={flightDateRef}
            />
          </div>
          <div className="col">
            <input
              class="form-control"
              type="text"
              placeholder="Enter Airline Name"
              aria-label=".form-control-sm example"
              ref={airlineNameref}
            />
          </div>
          <div className="col">
            <input
              class="form-control"
              type="number"
              placeholder="Enter Total Tickets"
              aria-label=".form-control-sm example"
              ref={totalTicketsRef}
              min={1}
            />
          </div>
          <div className="col">
            <input
              class="form-control"
              type="number"
              placeholder="Enter Ticket Price"
              aria-label=".form-control-sm example"
              min={1}
              ref={priceRef}
            />
          </div>
        </div>
        <div className="row align-items-center">
          <div className="col"></div>
          <div className="col-2 ">
            <button type="submit" class="shadow-sm   btn btn-outline-primary">
              Add New Flights
            </button>
          </div>
          <div className="col"></div>
        </div>
        <br />
        <div className="row"></div>
      </form>
    </React.Fragment>
  );
};

export default FlightManageForm;
