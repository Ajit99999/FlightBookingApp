import React from "react";
import { authContext } from "../../auth-context/auth-context";
import { useHistory } from "react-router";
import { useContext , useState , useEffect } from "react";
import { AiTwotoneDelete } from 'react-icons/ai';
import {  WiDegrees } from "react-icons/wi"
const OrderItem = (props) => {
  let history = useHistory();
  
  let orderId = props.orderId;
  let flightId = props.flightid;
  let storedToken = localStorage.getItem("token");
  

 

  

  let url = `http://localhost:8000/api/order/deleteorder/${orderId}/${flightId}`;

  const onDeleteHandler = async () => {
    try {
      let response = await fetch(url, {
        method: "DELETE",
        headers: {
          Authorization: storedToken,
        },
      });

      if (!response.ok) {
        console.log("error");
      }

      props.overallOrder();
      history.replace("/");
    } catch (err) {
      console.log(err.message);
    }
  };
  return (
    <div className="container col-6  shadow-lg bg-body rounded">
      <div className="row pt-4 pb-3 border-bottom bg-info">  
      <div className="d-flex justify-content-center text-dark "> Ticket Order Details </div>
      </div>
      <div className="row pt-4 ">
        <div className="col-3 ps-4 bg-light"> Flight ID </div>
        <div className="col-3 ps-4 bg-light "> Arrival </div>
        <div className="col-3 ps-4 bg-light"> Destination </div>
        <div className="col-3 ps-4 bg-light "> Flight Date</div>
      </div>
      <div className="row pt-2">
        <div className="col-3 ps-4"> {`F${props.flightid.slice(0, 3)}`} </div>
        <div className="col-3 ps-4"> {props.fromPlace} </div>
        <div className="col-3 ps-4"> {props.toPlace} </div>
        <div className="col-3 ps-4"> {props.flightDate.slice(0, 10)}</div>
      </div>
      <div className="row mt-3">
        <div className="col-3 ps-4 bg-light"> AirlineName </div>
        <div className="col-3 ps-4 bg-light"> Price </div>
        <div className="col-3 ps-4 bg-light"> Weather Details </div>
      </div>
      <div className="row">
        <div className="col-3 ps-4"> {props.airlineName} </div>
        <div className="col-3 ps-4"> {props.price} </div>
        <div className="col-4 ps-4"> { props.weather ? props.weather.slice(0,4) : "" } 
         <WiDegrees style={{width:"40px" , height:"40px" , marginLeft:"-15px" }}></WiDegrees>
         { props.weather ? props.weather.slice(4) : "" } 
        </div>
        </div>
      <div className="row mt-4">
      <div style={{  marginLeft:"400px" }}  className=" col-3 align-self-end mb-4">
          <button className=" text-light rounded-pill bg-danger border border-2 px-4" type="button" onClick={onDeleteHandler}>
          <AiTwotoneDelete />  Delete
          </button>
        </div>
      </div>
       
        
    
    </div>
  );
};

export default OrderItem;
