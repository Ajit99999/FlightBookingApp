import React from "react";

const AllOrderItem = (props) => {
 
  return (
    <React.Fragment>
         <div className="container col-md-6 mt-4  shadow-lg  bg-body rounded">
        <div className="row mt-4 pt-2 border pb-2   bg-secondary  border-2"> 
        <div className="col ps-4"> Order-ID  </div>  
        <div className="col ps-4"> Flight-ID  </div>
        <div className="col ps-4 "> Flight-Date  </div>
           </div>
           <div className="row mb-2 pt-2  "> 
        <div className="col ps-4 ">  {  `OD${props.orderId.slice(0,4)}`} </div>  
        <div className="col ps-4"> { `F${props.flightId.slice(0,4)}` } </div>
        <div className="col ps-4">   {props.flightDate.slice(0,10)} </div>
           </div>
          
           <div className="row border pt-2 pb-2 bg-secondary  border-2"> 
        <div className="col ps-4 "> Airline-Name </div>  
        <div className="col ps-4"> Arrival   </div>
        <div className="col ps-4"> Destination </div>
           </div>
           <div className="row pt-2 " > 
        <div className="col  ps-4 "> { props.airlineName } </div>  
        <div className="col ps-4 ">{ props.fromPlace } </div>
        <div className="col ps-4 mb-2">  { props.toPlace } </div>
           </div>
           </div>
        
       
     
    </React.Fragment>
  );
};
export default AllOrderItem;
