import React from "react";
import Auth from "../components/Auth";

const UserPage = (props)=>{
   return <Auth></Auth>
}
export default UserPage;