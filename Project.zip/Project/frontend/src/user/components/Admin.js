import React, { useState, useContext } from "react";
import { authContext } from "../../auth-context/auth-context";
import Card from "../../shared/Card/Card";
import Input from "../../shared/UIelements/Input";
import Button from "../../shared/UIelements/Button";

import {
  VALIDATOR_EMAIL,
  VALIDATOR_MIN,
  
  VALIDATOR_PASSWORD,
  VALIDATOR_REQUIRE,
} from "../../shared/Validator/validators";
import { useForm } from "../../shared/hooks/form-hook";
import './Admin';
import LoadingSpinner from "../../shared/UIelements/LoadingSpinner";
import { useHistory } from "react-router-dom";
const Admin = () => {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const history = useHistory();

  const [loadingState, setloadingState] = useState(false);
  const [errorState, seterrorState] = useState(null);
  const ctx = useContext(authContext);

  const [formState, inputHandler, setFormData] = useForm(
    {
      email: {
        value: "",
        isValid: false,
      },
      password: {
        value: "",
        isValid: false,
      },
    },
    false
  );

  const switchModeHandler = () => {
    if (!isLoginMode) {
      seterrorState(null);
      setFormData(
        {
          ...formState.inputs,
          name: undefined,
        },
        formState.inputs.email.isValid && formState.inputs.password.isValid
      );
    } else {
      seterrorState(null);
      setFormData(
        {
          ...formState.inputs,
          name: {
            value: "",
            isValid: false,
          },
          age: {
            value: "",
            isValid: false,
          },
          address: {
            value: "",
            isValid: false,
          },
        },
        false
      );
    }
    setIsLoginMode((prevMode) => !prevMode);
  };

  const authSubmitHandler = async (event) => {
    event.preventDefault();
    if (isLoginMode) {
      try {
        setloadingState(true);
        let response = await fetch("http://localhost:8000/api/user/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            password: formState.inputs.password.value,
            email: formState.inputs.email.value,
          }),
        });
        setloadingState(false);

        let data = await response.json();
        if (!response.ok) {
          throw new Error(data.message);
        }
        ctx.login(data.user.userId,data.user.token);
         ctx.setuserDetails(
          {
            name:data.user.name,
            address:data.user.userAddress,
            email:data.user.userEmail,
            role:data.user.role,
            totalPrice:data.user.totalPrice
          }
        )
        console.log(data.user.role);
        history.replace("/");
      } catch (err) {
        setloadingState(false);
        seterrorState(err.message);
      }


    } else {
      try {
        setloadingState(true);
        let response = await fetch("http://localhost:8000/api/user/signup", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            name: formState.inputs.name.value,
            password: formState.inputs.password.value,
            email: formState.inputs.email.value,
            age: formState.inputs.age.value,
            address: formState.inputs.address.value,
            role:1
          }),
        });
        setloadingState(false);

        let data = await response.json();
        if (!response.ok) {
          throw new Error(data.message);
        }
        console.log(data);
        ctx.login(data.user.userId,data.user.token);
        ctx.setuserDetails(
          {
            name:data.user.name,
            address:data.user.userAddress,
            email:data.user.userEmail,
            role:data.user.role,
            totalPrice:data.user.totalPrice
          }
        )
        history.replace("/");
      } catch (err) {
        setloadingState(false);
        seterrorState(err.message);
      }
    }
   

  };

 
 
  return (
    <React.Fragment>
   
      <Card className="authentication">
        {loadingState && <LoadingSpinner asOverlay></LoadingSpinner>}
        {!isLoginMode ? <h5> Admin Sign Up Required</h5> : <h5> Admin Login Required</h5>}
        <hr />
        <form onSubmit={authSubmitHandler}>
          {!isLoginMode && (
            <Input
              element="input"
              id="name"
              type="text"
              label="Your Name"
              validators={[VALIDATOR_REQUIRE()]}
              errorText="Please enter a name."
              onInput={inputHandler}
            />
          )}
          <Input
            element="input"
            id="email"
            type="email"
            label="E-Mail"
            validators={[VALIDATOR_EMAIL()]}
            errorText="Please enter a valid email address."
            onInput={inputHandler}
          />
          <Input
            element="input"
            id="password"
            type="password"
            label="Password"
            validators={[VALIDATOR_PASSWORD()]}
            errorText="Please enter a valid password, at least 6 characters."
            onInput={inputHandler}
          />
          {!isLoginMode && (
            <Input
              element="input"
              id="age"
              type="age"
              label="Age"
              validators={[VALIDATOR_REQUIRE(), VALIDATOR_MIN(18)]}
              errorText="Please enter a valid Age "
              onInput={inputHandler}
            />
          )}
          {!isLoginMode && (
            <Input
              element="input"
              id="address"
              type="address"
              label="Address"
              validators={[VALIDATOR_REQUIRE()]}
              errorText="Please enter a valid Address "
              onInput={inputHandler}
            />
          )}
          { errorState && <p style={{ color:"red"}} > {errorState} </p>  }
          <Button type="submit" disabled={!formState.isValid}>
            {isLoginMode ? "LOGIN" : "SIGNUP"}
          </Button>
        </form>
        <Button inverse onClick={switchModeHandler}>
          SWITCH TO {isLoginMode ? "SIGNUP" : "LOGIN"}
        </Button>
      </Card>
    </React.Fragment>
  );
};

export default Admin;
