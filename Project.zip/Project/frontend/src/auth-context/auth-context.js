import React from "react";

import { createContext, useState, useEffect } from "react";

export const authContext = createContext({
  isLogged: false,
  login: (userId, token) => {},
  logout: () => {},
  orderId: null,
  setorderId: (data) => {},
  userDetails: null,
  setuserDetails: (data) => {},
  searchButtonClick: () => {},
  searchButton: false,
  role:null
});

const AuthContextComponent = (props) => {

  let storedToken = localStorage.getItem('token');
  let locaOrderId = localStorage.getItem('orderId');
  let userDetails = localStorage.getItem('userDetails');
  userDetails = JSON.parse(userDetails);
  console.log(userDetails );
  
  let intialtoken ;
  let intiallogValue;
  let intialOrderId;
  let intialuserDetails;
  let userrole;
  if(storedToken){
    intialtoken = storedToken;
    intiallogValue = true;
  }
  else{
    intiallogValue = false;
  }

  if(locaOrderId){
    intialOrderId = locaOrderId;
  }


  if(userDetails){
    intialuserDetails = userDetails;
    userrole = intialuserDetails.role;
  }
  else{
    userrole = null;
  }


  const [loggedValue, setloggedValue] = useState(intiallogValue);
  const [orderId, setorderId] = useState(intialOrderId);
  const [userDataDetails, setuserDataDetails] = useState(intialuserDetails);
  const [searchbutton, setsearchbutton] = useState(false);
  const[role , setrole] = useState(userrole);
  


  const [ tokenId , settokenId ] = useState(intialtoken);

  const loginHandler = (userId, token) => {
 
    settokenId(token);
    localStorage.setItem("token" , token);
    localStorage.setItem("userId", userId);
    setloggedValue(true);
  };
  const logoutHandler = () => {
    setloggedValue(false);

    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('orderId');
    localStorage.removeItem('userDetails')
    setrole(null);
  };
  const setorderIdHandler = (data) => {
    setorderId(data);

    localStorage.setItem('orderId', data);
  };
  const setuserDataDetailsHandler = (data) => {
    setsearchbutton(true);
    setuserDataDetails(data);
    localStorage.setItem("userDetails", JSON.stringify(data));
    setrole(data.role);

  };

  const setsearchbuttonHandler = () => {
    setsearchbutton(true);
  };

  let infoObject = {
    isLogged: loggedValue,
    login: loginHandler,
    logout: logoutHandler,
    setorderId: setorderIdHandler,
    orderId: orderId,
    userDetails: userDataDetails,
    setuserDetails: setuserDataDetailsHandler,
    searchButton: searchbutton,
    searchButtonClick: setsearchbuttonHandler,
    role:role
  };
  return (
    <authContext.Provider value={infoObject}>
      {props.children}
    </authContext.Provider>
  );
};

export default AuthContextComponent;
