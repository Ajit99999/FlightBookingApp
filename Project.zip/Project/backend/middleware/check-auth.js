const jwt = require('jsonwebtoken');
const HttpError = require('../model/error-model');
const checkAuth = (req,res,next)=>{
    try {
        const token = req.headers.authorization;
        
        if (!token) {
          
          const error = new HttpError("Authentication Failed", 404);
          return next(error);
        }
        const payload = jwt.verify(token, "secret-key");
        req.userdata = { userId: payload.userId };
         next();
      } catch (err) {
       
        
        const error = new HttpError("Authentication Failed", 404);
        return next(error);
      }
}
module.exports = checkAuth;