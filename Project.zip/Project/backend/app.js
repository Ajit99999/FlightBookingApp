const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require('cors');
const mongoose = require("mongoose");
const userRoute = require("./routes/user-routes");
const flightRoute = require("./routes/flight-routes");
let databaseurl = '';
const HttpError = require("./model/error-model");
const orderRoute = require("./routes/order-routes");
app.use(bodyParser.json());

app.use(cors());
app.use("/api/user", userRoute);
app.use("/api/flight", flightRoute);

app.use("/api/order", orderRoute);
app.use((req, res, next) => {
  const error = new HttpError("Could not find this route.", 404);
  return next(error);
});
app.use((error, req, res, next) => {
  if (res.headerSent) {
    return next(error);
  }
  res.status(error.code || 500);
  res.json({ message: error.message || "An unknown error occurred!" });
});

mongoose
  .connect(
   databaseurl
  )
  .then(() => {
    app.listen(8000, () => {
      console.log("server running");
    });
  })
  .catch((err) => {
    console.log(err.message);
  });
