const User = require("../model/user");
const HttpError = require("../model/error-model");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const Order = require("../model/order");
const Flight = require("../model/flight");
const { validationResult } = require("express-validator");

const login = async (req, res, next) => {
  const { email, password } = req.body;
  let identifyingUser;
  try {
    identifyingUser = await User.findOne({ email: email }).exec();
  } catch (err) {
    const error = new HttpError("Data Fetching Failed", 404);
    return next(error);
  }

  if (!identifyingUser) {
    const error = new HttpError("User Doesnot Exists", 404);
    return next(error);
  }

  let match;
  try {
    match = await bcrypt.compare(password, identifyingUser.password);
  } catch (err) {
    const error = new HttpError("Hashing Password Failed", 500);
    return next(error);
  }

  if (!match) {
    const error = new HttpError("Invalid Credentials", 404);
    return next(error);
  }

  let token;
  try {
    token = jwt.sign(
      { userId: identifyingUser.id, email: identifyingUser.email },
      "secret-key",
      { expiresIn: "1hr" }
    );
  } catch (err) {
    const error = new HttpError("Please Try again", 500);
    return next(error);
  }

  if (identifyingUser.role === 1) {
    res.json({
      user: {
        userId: identifyingUser.id,
        userEmail: identifyingUser.email,
        token,
        userAddress: identifyingUser.address,
        name: identifyingUser.name,
        role:identifyingUser.role,
        totalPrice: identifyingUser.totalPrice
      },
      role: "admin",
    });
  } else {
    res.json({
      user: {
        userId: identifyingUser.id,
        userEmail: identifyingUser.email,
        token,
        userAddress: identifyingUser.address,
        name: identifyingUser.name,
        role:identifyingUser.role,
        totalPrice: identifyingUser.totalPrice
      },
      role: "User",
    });
  }
};

const signup = async (req, res, next) => {
  let { name, email, password, age, address, role } = req.body;
  let createdUser;
  let existingUser;
  let errObj;
  errObj = validationResult(req);

  age = parseInt(age);
  role = parseInt(role);
  console.log(typeof role);
  if (!errObj.isEmpty()) {
    const error = new HttpError("Please Check Input Fields", 404);
    return next(error);
  }
  try {
    existingUser = await User.findOne({ email: email }).exec();
  } catch (err) {
    const error = new HttpError("Data Fetching Failed", 404);
    return next(error);
  }

  if (existingUser) {
    const error = new HttpError("User already exists", 404);
    return next(error);
  }
  let hash_password;
  try {
    hash_password = await bcrypt.hash(password, 12);
  } catch (err) {
    const error = new HttpError("Hashing Password Failed", 500);
    return next(error);
  }

  if (role === 1) {
    try {
      createdUser = new User({
        name: name,
        email: email,
        password: hash_password,
        age: age,
        address: address,
        role: role,
        orders: [],
        flights: [],
      });
    } catch (err) {
      const error = new HttpError("Data Fetching Failed", 404);
      return next(error);
    }
  } else {
    try {
      createdUser = new User({
        name: name,
        email: email,
        password: hash_password,
        age: age,
        address: address,
        orders: [],
        flights: [],
      });
    } catch (err) {
      const error = new HttpError("Data Fetching Failed", 404);
      return next(error);
    }
  }

  try {
    await createdUser.save();
  } catch (err) {
    const error = new HttpError("Saving Data Failed", 404);
    return next(error);
  }

  let token;
  try {
    token = jwt.sign(
      { userId: createdUser.id, email: createdUser.id },
      "secret-key",
      { expiresIn: "1hr" }
    );
  } catch (err) {
    const error = new HttpError("Please Try again", 500);
    return next(error);
  }

  res.json({
    user: {
      userId: createdUser.id,
      token,
      userEmail: createdUser.email,
      role: createdUser.role,
      userAddress:createdUser.address,
      name:createdUser.name,
      totalPrice: createdUser.totalPrice
    },
  });
};

const getOrders = async (req, res, next) => {
  let userId = req.params.userId;
  let existingUser;
  let existingUser2;

  try {
    existingUser = await User.findById(userId).populate("flights").exec();
  } catch (err) {
    const error = new HttpError("Searching Request Failed", 500);
    return next(error);
  }

  if (!existingUser) {
    const error = new HttpError("User is not Present", 500);
    return next(error);
  }
  try {
    existingUser2 = await User.findById(userId).populate("orders").exec();
  } catch (err) {
    const error = new HttpError("Searching Request Failed", 500);
    return next(error);
  }

  res.json({
    FlightsDetails: existingUser.flights,
    ordersDetails: existingUser2.orders,
  });
};

const searchflight = async (req, res, next) => {
  let { fromPlace, toPlace, fromDate, toDate } = req.body;
  console.log(fromDate);
  console.log(toDate);
  console.log(fromPlace);
  console.log(toPlace);
  let existingFlight;

  fromDate = new Date(fromDate);

  if (toDate === undefined) {
  } else {
    toDate = new Date(toDate);

    if (fromDate < toDate) {
      const error = new HttpError(
        "From date can not be greater than To Date",
        404
      );
      return next(error);
    }
  }

  if (toDate === undefined) {
    try {
      console.log("to date not present");

      existingFlight = await Flight.find({
        fromPlace: { $regex: new RegExp(`^${fromPlace}$`), $options: "i" },
        toPlace: { $regex: new RegExp(`^${toPlace}$`), $options: "i" },
        flightDate: { $gte: fromDate },
      }).exec();
    } catch (err) {
      const error = new HttpError("Data Searching Failed", 404);
      return next(error);
    }
  } else {
    try {
      console.log("to date  present");
      existingFlight = await Flight.find({
        fromPlace: { $regex: new RegExp(`^${fromPlace}$`), $options: "i" },
        toPlace: { $regex: new RegExp(`^${toPlace}$`), $options: "i" },
        $and: [
          { flightDate: { $gte: fromDate }, flightDate: { $lte: toDate } },
        ],
      }).exec();
    } catch (err) {
      const error = new HttpError("Data Searching Failed", 404);
      return next(error);
    }
  }

  if (existingFlight.length === 0) {
    const error = new HttpError("No Flights Present", 404);
    return next(error);
  }

  res.json({
    message: "Fetching Sucessful",
    flight: existingFlight,
  });
};

const searchbyAirlines = async (req, res, next) => {
  let { fromPlace, toPlace, fromDate, toDate, airlineName } = req.body;

  let existingFlight;

  fromDate = new Date(fromDate);

  if (toDate === undefined) {
  } else {
    toDate = new Date(toDate);

    if (fromDate > toDate) {
      const error = new HttpError(
        "From date can not be greater than To Date",
        404
      );
      return next(error);
    }
  }

  if (toDate === undefined) {
    try {
      existingFlight = await Flight.find({
        fromPlace: { $regex: new RegExp(`^${fromPlace}$`), $options: "i" },
        toPlace: { $regex: new RegExp(`^${toPlace}$`), $options: "i" },
        airlineName: { $regex: new RegExp(`^${airlineName}$`), $options: "i" },
        flightDate: { $gte: fromDate },
      }).exec();
    } catch (err) {
      const error = new HttpError("Data Searching Failed", 404);
      return next(error);
    }
  } else {
    try {
      console.log("to date  present");
      existingFlight = await Flight.find({
        fromPlace: { $regex: new RegExp(`^${fromPlace}$`), $options: "i" },
        toPlace: { $regex: new RegExp(`^${toPlace}$`), $options: "i" },
        airlineName: { $regex: new RegExp(`^${airlineName}$`), $options: "i" },
        $and: [
          { flightDate: { $gte: fromDate }, flightDate: { $lte: toDate } },
        ],
      }).exec();
    } catch (err) {
      const error = new HttpError("Data Searching Failed", 404);
      return next(error);
    }
  }

  if (existingFlight.length === 0) {
    const error = new HttpError("No Flights Present", 404);
    return next(error);
  }

  res.json({
    message: "Fetching Sucessful",
    flight: existingFlight,
  });
};

const getOrdersByUserId = async (req, res, next) => {
  let userId = req.params.userId;
  let existingOrder;
  let existingUser;
  try {
    existingOrder = await Order.find({
      creator: userId,
    }).populate('flight');
  } catch (err) {

   const error = new HttpError('Order date fetching Request failed', 500)
   return next(error);

  }
   
  if(existingOrder.length === 0){
    
    const error = new HttpError('No Orders data is Present', 500)
    return next(error);

  }

  try {
    existingUser = await Order.find({
      creator: userId,
    }).populate('creator');
  } catch (err) {

   const error = new HttpError('Order date fetching Request failed', 500)
   return next(error);

  }
  
  res.json({
    orders: existingOrder,
    user:existingUser
  })


};
exports.getOrders = getOrders;
exports.getOrdersByUserId = getOrdersByUserId;
exports.login = login;
exports.signup = signup;
exports.searchflight = searchflight;
exports.searchbyAirlines = searchbyAirlines;
