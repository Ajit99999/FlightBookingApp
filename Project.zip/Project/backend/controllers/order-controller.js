const Order = require("../model/order");
const Flight = require("../model/flight");
const HttpError = require("../model/error-model");
const mongoose = require("mongoose");
const User = require("../model/user");

const createOrder = async (req, res, next) => {
  const { flightId, creator } = req.body;
  let flightDetails;
  let userDetails;
  let newOrder;
  let existingOrder;

  

  try {
    flightDetails = await Flight.findById(flightId);
  } catch (err) {
    const error = new HttpError("Flight data Fetching Failed", 404);
    return next(error);
  }
  try {
    userDetails = await User.findById(creator);
  } catch (err) {
    const error = new HttpError("User data Fetching Failed", 404);
    return next(error);
  }

  if (!flightDetails || !userDetails) {
    const error = new HttpError("Flight or UserDetails not present");
    return next(error);
  }
 

  newOrder = new Order({
    creator: creator,
    flight: flightId,
  });

  userDetails.totalPrice = userDetails.totalPrice + flightDetails.price;

  try {
    const session = await mongoose.startSession();
    session.startTransaction();
    await newOrder.save();
    userDetails.orders.push(newOrder);
    userDetails.flights.push(flightId);
    await userDetails.save();
    flightDetails.totalTickets = flightDetails.totalTickets - 1;
    flightDetails.save();
    session.commitTransaction();
  } catch (err) {
    const error = new HttpError("Order is not Created ", 500);
    return next(error);
  }

  res.json({
    order: newOrder.toObject({ getters: true }),
  });
};

const deleteOrder = async (req, res, next) => {
  let orderId = req.params.orderId;
  let flightId = req.params.flightId;
  let existingFlight;
  let existingOrder;
  try {
    existingOrder = await Order.findById(orderId).populate("creator");
  } catch (err) {
    const error = new HttpError("Deleting Request is Failed", 404);
    return next(error);
  }

  if (!existingOrder) {
    const error = new HttpError("This Order is Not Present", 404);
    return next(error);
  }

  if (existingOrder.flight.toString() !== flightId) {
    const error = new HttpError("This Flight id is different", 404);
    return next(error);
  }
  try {
    existingFlight = await Flight.findById(flightId);
  } catch (err) {
    const error = new HttpError("Flight data fetching failed", 404);
    return next(error);
  }

  try {
    const session = await mongoose.startSession();
    session.startTransaction();
    await existingOrder.remove({
      session: session,
    });

    existingOrder.creator.orders.pull(existingOrder);
    existingOrder.creator.flights.pull(flightId);
    existingOrder.creator.totalPrice =
      existingOrder.creator.totalPrice - existingFlight.price;
    await existingOrder.creator.save({ session: session });
    session.commitTransaction();
  } catch (err) {
    const error = new HttpError("Deletion Failed", 404);
    return next(error);
  }

  existingFlight.totalTickets = existingFlight.totalTickets + 1;
  try {
    await existingFlight.save();
  } catch (err) {
    const error = new HttpError("Flight data Saving failed", 404);
    return next(error);
  }

  res.json({
    message: "Delete Order Sucessful",
  });
};
const searchOrder = async (req, res, next) => {
  let orderId = req.params.orderId;
  let existingOrder;
  let flightDetails;

  try {
    existingOrder = await Order.findById(orderId).populate("creator");
  } catch (err) {
    const error = new HttpError("Order data Fetching Failed", 404);
    return next(error);
  }

  try {
    flightDetails = await Order.findById(orderId).populate("flight");
  } catch (err) {
    const error = new HttpError("Order data Fetching Failed", 404);
    return next(error);
  }
  if (!existingOrder) {
    const error = new HttpError("This Order Data is Not Present", 404);
    return next(error);
  }
  res.json({
    existingOrder: existingOrder.toObject({ getters: true }),
    flightDetails: flightDetails,
  });
};
exports.searchOrder = searchOrder;
exports.deleteOrder = deleteOrder;
exports.createOrder = createOrder;
