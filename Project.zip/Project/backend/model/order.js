const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema({
  creator: {
    type: mongoose.Types.ObjectId,
    required: true,
    ref: "User"
  },

  flight: {
    type: mongoose.Types.ObjectId,
    required: true,
    ref: "Flight"
  },
});

module.exports = mongoose.model("Order", orderSchema);
