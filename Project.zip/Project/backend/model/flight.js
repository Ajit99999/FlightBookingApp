const mongoose = require("mongoose");

const flightSchema = new mongoose.Schema({
  fromPlace: {
    type: String,
    required: true,
    index: {
      collation: {
        locale: "en",
        strength: 2,
      },
    },
  },
  toPlace: {
    type: String,
    required: true,
    index: {
      collation: {
        locale: "en",
        strength: 2,
      },
    },
  },
  flightDate: {
    type: Date,
    required: true,
  },
  totalTickets: {
    type: Number,
    required: true,
  },
  airlineName: {
    type: String,
    required: true,
    index: {
      collation: {
        locale: "en",
        strength: 2,
      },
    },
  },
  price:{
    type:Number,
    required:true
  }


});
module.exports = mongoose.model('Flight',flightSchema);

