const express = require("express");
const Router = express.Router();
const checkAuth = require('../middleware/check-auth');

const flightController = require('../controllers/flight-controller');
Router.use(checkAuth);
Router.post('/createflight',flightController.createFlights);
Router.patch('/updateflight/:fid',flightController.updateFlight);
Router.delete('/deleteflight/:fid',flightController.deleteFlight);
Router.get('/getflights', flightController.getFlights);
// Router.post('/searchflight',flightController.searchflight);
module.exports = Router;