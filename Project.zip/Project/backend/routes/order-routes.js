const express = require("express");
const Router = express.Router();
const orderController = require('../controllers/order-controller');

const checkAuth = require('../middleware/check-auth');
Router.use(checkAuth);
Router.post('/createorder' ,orderController.createOrder);
Router.delete('/deleteorder/:orderId/:flightId', orderController.deleteOrder);
Router.get('/searchorder/:orderId', orderController.searchOrder);
module.exports = Router;