const express = require("express");
const Router = express.Router();
const checkAuth = require('../middleware/check-auth');
const { check } = require("express-validator");
const userController = require("../controllers/user-controller");
Router.post('/searchflight',userController.searchflight);
Router.post('/searchbyairline',userController.searchbyAirlines);

Router.post("/login", userController.login);
Router.post(
  "/signup",
  [
    check("name").not().isEmpty(),
    check("email").isEmail(),
    check("password").not().isEmpty().isLength({ min: 6 }),
    check("address").not().isEmpty(),
    check("age").not().isEmpty(),
  ],
  userController.signup
);
Router.use(checkAuth);
Router.get('/getOrders/:userId',userController.getOrders);
Router.get('/orders/:userId', userController.getOrdersByUserId);
module.exports = Router;
