const HttpError = require("../model/error-model");
const Flight = require("../model/flight");

const User = require("../model/user");



const createFlights = async (req, res, next) => {
  let { fromPlace, toPlace, flightDate, totalTickets, airlineName , price } = req.body;

  let newFlight;
  let existingFlight;
  flightDate = new Date(flightDate);
  console.log(typeof flightDate);
  try{
     existingFlight = await Flight.find({
      fromPlace : fromPlace,
      toPlace: toPlace,
      flightDate : flightDate,
      totalTickets: totalTickets,
      airlineName:airlineName,
      price:price
     })
  }
  catch(err){
    const error = new HttpError("Flight Data Creation failed", 500);
    return next(error);
  }
  
  if(existingFlight.length !== 0){
    const error = new HttpError("Flight Data Already Existed", 500);
    return next(error);
  }

  
  try {
    newFlight = new Flight({
      fromPlace: fromPlace,
      toPlace: toPlace,
      flightDate: new Date(flightDate),
      totalTickets: totalTickets,
      airlineName: airlineName,
      price:price
    });
  } catch (err) {
    const error = new HttpError("Creation failed", 404);
    return next(error);
  }

  try {
    await newFlight.save();
  } catch (err) {
    const error = new HttpError("Saving Data Failed", 404);
    return next(error);
  }

  res.json({
    flight: newFlight.toObject({ getters: true }),
  });
};
const deleteFlight = async (req, res, next) => {
  const flightId = req.params.fid;
  
  let existingFlight;
  try {
    existingFlight = await Flight.findById(flightId).exec();
  } catch (err) {
    const error = new HttpError("Date deleting request failed", 500);
    return next(error);
  }
  if (!existingFlight) {
    const error = new HttpError("This Flight Id doesnot exists", 404);
    return next(error);
  }
  try {
    await existingFlight.remove();
  } catch (err) {
    const error = new HttpError("Flight Data deletion failed", 404);
    return next(error);
  }

  res.json({
    message: "Data deletion Sucessful",
  });
};

const updateFlight = async (req, res, next) => {
  const { fromPlace, toPlace, flightDate, totalTickets, airlineName , price } = req.body;
  let existingFlight;
  // let existingFlight2;
  const flightId = req.params.fid;
  
  // try{
  //   existingFlight2 = await Flight.find({
  //     fromPlace : fromPlace,
  //     toPlace: toPlace,
  //     flightDate : flightDate,
  //     totalTickets: totalTickets,
  //     airlineName:airlineName,
  //     price:price
  //    })
  // }
  // catch(err){
  //   const error = new HttpError("Flight Data Updating Request failed", 500);
  //   return next(error);
  // }

  // if (existingFlight2.length !== 0) {
  //   const error = new HttpError("This Flights Data already exists", 404);
  //   return next(error);
  // }

  try {
    existingFlight = await Flight.findById(flightId).exec();
  } catch (err) {
    const error = new HttpError("Data Updating request failed", 500);
    return next(error);
  }

  if (!existingFlight) {
    const error = new HttpError("This Flight Id doesnot exists", 404);
    return next(error);
  }

  existingFlight.fromPlace = fromPlace;
  existingFlight.toPlace = toPlace;
  existingFlight.totalTickets = totalTickets;
  existingFlight.airlineName = airlineName;
  existingFlight.flightDate = new Date(flightDate);
  existingFlight.price = price;

  try {
    await existingFlight.save();
  } catch (err) {
    const error = new HttpError("Saving this Flight data failed", 500);
    return next(error);
  }

  res.json({
    message: "Flights Update Successful",
    flight: existingFlight.toObject({ getters: true }),
  });
};

// const searchflight = async (req, res, next) => {
//   let { fromPlace, toPlace, fromDate, toDate } = req.body;

//   let existingFlight;

//   fromDate = new Date(fromDate);
//   // toDate = new Date(toDate);
  

//   if (toDate === undefined) {
//   } else {
//     toDate = new Date(toDate);

//     if(fromDate > toDate){
//       const error = new HttpError('From date can not be greater than To Date',404);
//       return next(error);
//     }
//   }

//   if (toDate === undefined) {
//     try {
//       console.log("to date not present");
//       //    existingFlight = await Flight.find({ fromPlace: fromPlace , toPlace : toPlace ,flightDate:{ $gte:fromDate }  }).exec();
//       existingFlight = await Flight.find({
//         fromPlace: { $regex: new RegExp(`^${fromPlace}$`), $options: "i" },
//         toPlace: { $regex: new RegExp(`^${toPlace}$`), $options: "i" },
//         flightDate: { $gte: fromDate },
//       }).exec();
//     } catch (err) {
//       const error = new HttpError("Data Searching Failed", 404);
//       return next(error);
//     }
//   } else {
//     try {
//       console.log("to date  present");
//       existingFlight = await Flight.find({
//         fromPlace: { $regex: new RegExp(`^${fromPlace}$`), $options: "i" },
//         toPlace: { $regex: new RegExp(`^${toPlace}$`), $options: "i" },
//         $and: [
//           { flightDate: { $gte: fromDate }, flightDate: { $lte: toDate } },
//         ],
//       }).exec();
//     } catch (err) {
//       const error = new HttpError("Data Searching Failed", 404);
//       return next(error);
//     }
//   }

//   if (existingFlight.length === 0) {
//     const error = new HttpError("No Flights Present", 404);
//     return next(error);
//   }

//   res.json({
//     message: "Fetching Sucessful",
//     flight: existingFlight,
//   });
// };
const getFlights = async (req,res,next)=>{

   let existingFlights;

   try{
     existingFlights = await Flight.find().exec();

   }
   catch(err){
      const error = new HttpError("Data Searching Failed", 404);
      return next(error);
   }
   

   res.json({
    flights : existingFlights
   })

}
exports.deleteFlight = deleteFlight;
exports.updateFlight = updateFlight;
exports.createFlights = createFlights;
exports.getFlights = getFlights;

